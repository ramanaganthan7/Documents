import readline from "readline";
import fs from "fs";
import path from "path";
import { stringify } from "csv-stringify/sync";
import { callVertexModel } from "./services/vertex.js";
import {buildPseudocodePrompt,buildTopicPrompt} from "./services/template.js";

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

/* ---------------- OUTPUT SETUP ---------------- */

const OUTPUT_DIR = "./output";
if (!fs.existsSync(OUTPUT_DIR)) fs.mkdirSync(OUTPUT_DIR);

const now = new Date();
const pad = n => String(n).padStart(2, "0");
const timestamp =
  `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}_` +
  `${pad(now.getHours())}-${pad(now.getMinutes())}-${pad(now.getSeconds())}`;

const OUTPUT_FILE = path.join(
  OUTPUT_DIR,
  `questions_${timestamp}.csv`
);


/* ---------------- CONFIG ---------------- */

const BATCH_SIZE = 5;

/* ---------------- VALIDATION ---------------- */

function isValidBatch(json, expectedCount, isPseudocodeMode) {
  if (!json || !Array.isArray(json.questions)) {
    console.warn("❌ Invalid JSON structure");
    return false;
  }

  if (json.questions.length !== expectedCount) {
    console.warn(
      `❌ Question count mismatch. Expected ${expectedCount}, got ${json.questions.length}`
    );
    return false;
  }

  for (const q of json.questions) {
    if (
      typeof q.question !== "string" ||
      typeof q.explanation !== "string" ||
      typeof q.answer !== "number" ||
      q.answer < 1 ||
      q.answer > 4 ||
      !q.options ||
      !["1", "2", "3", "4"].every(k => typeof q.options[k] === "string")
    ) {
      console.warn("❌ Schema field validation failed");
      return false;
    }

    if (isPseudocodeMode && typeof q.pseudocode !== "string") {
      console.warn("❌ Missing pseudocode field in pseudocode mode");
      return false;
    }
  }

  return true;
}

/* ---------------- UTILS ---------------- */

function cleanJSON(text) {
  return text.replace(/```json|```/gi, "").trim();
}

function ask(question) {
  return new Promise(resolve => rl.question(question, resolve));
}

/* ---------------- LLM WITH RETRY ---------------- */

async function generateBatch(promptBuilder, batchCount, isPseudocodeMode, retries = 4) {
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      console.log(`🤖 LLM Call | Attempt ${attempt} | Batch Size ${batchCount}`);

      const prompt = promptBuilder(batchCount);
      const raw = await callVertexModel(prompt);
      const parsed = JSON.parse(cleanJSON(raw));

      if (isValidBatch(parsed, batchCount, isPseudocodeMode)) {
        console.log("✅ Batch validated successfully");
        return parsed.questions;
      }

      console.warn("⚠️ Schema validation failed. Retrying...");
    } catch (err) {
      console.warn("❌ JSON parse / LLM error. Retrying...");
    }
  }

  throw new Error("🔥 LLM failed after 4 retries");
}

/* ---------------- MAIN FLOW ---------------- */

(async function main() {
  console.log("\n🧠 Select Generation Mode:");
  console.log("1️⃣  Pseudocode Questions");
  console.log("2️⃣  Topic-wise MCQ Questions\n");

  const mode = await ask("👉 Enter choice (1 or 2): ");
  let totalQuestions;
  let promptBuilder;
  let isPseudocodeMode = false;
  let sNo = 1;

  /* -------- MODE SELECTION -------- */

  if (mode === "1") {
    isPseudocodeMode = true;
    totalQuestions = Number(await ask("🔢 Enter total number of questions: "));
    promptBuilder = count => buildPseudocodePrompt(count);
  }
  else if (mode === "2") {
    const topic = await ask("📘 Enter topic name: ");
    totalQuestions = Number(await ask("🔢 Enter total number of questions: "));
    promptBuilder = count => buildTopicPrompt(topic, count);
  }
  else {
    console.log("❌ Invalid option. Exiting.");
    rl.close();
    return;
  }

  /* -------- CSV INIT (MODE AWARE) -------- */

  const columns = isPseudocodeMode
    ? ["S.No", "Question", "Pseudocode", "Options (JSON)", "Solution", "Explanation"]
    : ["S.No", "Question", "Options (JSON)", "Solution", "Explanation"];

  fs.writeFileSync(
    OUTPUT_FILE,
    stringify([], {
      header: true,
      columns
    })
  );

  console.log(`📄 CSV initialized with columns: ${columns.join(", ")}`);

  /* -------- BATCH GENERATION -------- */

  let remaining = totalQuestions;
  let batchNo = 1;

  while (remaining > 0) {
    const currentBatchSize = Math.min(BATCH_SIZE, remaining);

    console.log(
      `\n📦 Batch ${batchNo} | Generating ${currentBatchSize} question(s)`
    );

    const questions = await generateBatch(
      promptBuilder,
      currentBatchSize,
      isPseudocodeMode
    );

    for (const q of questions) {
      const row = isPseudocodeMode
        ? [[
            sNo,
            q.question,
            q.pseudocode,
            JSON.stringify(q.options),
            q.answer,
            q.explanation
          ]]
        : [[
            sNo,
            q.question,
            JSON.stringify(q.options),
            q.answer,
            q.explanation
          ]];

      fs.appendFileSync(OUTPUT_FILE, stringify(row));
      console.log(`📝 Saved Question ${sNo}`);
      sNo++;
    }

    remaining -= currentBatchSize;
    batchNo++;
  }

  console.log(
    `\n🎉 DONE! ${totalQuestions} questions saved successfully.\n📄 File: ${OUTPUT_FILE}`
  );

  rl.close();
})();
