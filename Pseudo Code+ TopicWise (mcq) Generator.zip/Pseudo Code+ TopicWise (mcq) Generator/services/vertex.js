import fetch from "node-fetch";

const API_KEY = "AQ.Ab8RN6L9MUlopqBRAe_6wNLvfZx-dmPFcrSi4uGvC0ny1m4zrg"; // replace with your valid API key

export async function callVertexModel(prompt) {
  const url = `https://aiplatform.googleapis.com/v1/publishers/google/models/gemini-2.5-pro:streamGenerateContent?key=${API_KEY}`;

  const body = {
    contents: [
      {
        role: "user",
        parts: [{ text: prompt }]
      }
    ]
  };

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });

    const rawText = await response.text();

    if (!response.ok) {
      console.error("❌ HTTP Error from Vertex API:", response.status, rawText.slice(0, 300));
      throw new Error(`Vertex API returned HTTP ${response.status}`);
    }

    // The response is a JSON array of chunks: [ {...}, {...} ]
    let parsed;
    try {
      parsed = JSON.parse(rawText);
    } catch (err) {
      console.error("❌ Unable to parse streamed JSON:", err.message);
      console.log("RAW STREAM:\n", rawText.slice(0, 500));
      throw new Error("Malformed JSON from Vertex API");
    }

    // Check for MAX_TOKENS truncation in any chunk
    const truncated = parsed.some(
      ch => ch.candidates?.[0]?.finishReason === "MAX_TOKENS"
    );
    if (truncated) {
      console.warn("⚠️  Model hit MAX_TOKENS — response is truncated (JSON will be incomplete)");
    }

    // Merge text parts from chunks
    const merged = parsed
      .map(ch => ch.candidates?.[0]?.content?.parts?.[0]?.text ?? "")
      .join("")
      .trim();

    if (!merged) {
      throw new Error("Empty or invalid response from LLM");
    }

    return merged;

  } catch (error) {
    console.error("❌ Vertex API Request Failed:", error.message);
    throw error;   // propagate so callLLMWithRetry can count the attempt
  }
}
