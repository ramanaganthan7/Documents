﻿/* ---------------- PSEUDOCODE PROMPT ---------------- */
export function buildPseudocodePrompt(batchCount) {
  return `
You are a TECH COMPANY INTERVIEW PSEUDOCODE MCQ GENERATOR FOR C PROGRAMMING.

YOUR GOAL:
Generate high-quality, service-based company interview questions (TCS / Infosys / Wipro)
covering ALL IMPORTANT C PROGRAMMING TOPICS across multiple LLM batches,
ensuring NO question is ever repeated or similar.

QUESTION RULES (STRICT):
1. Generate EXACTLY ${batchCount} questions.
2. ALL questions must be UNIQUE:
   - Unique within this batch
   - Unique compared to previous LLM batches
3. No similar logic, flow, structure, or dry-run pattern.
4. Each question MUST contain:
   - A clear problem statement (question field)
   - Corresponding pseudocode in a SEPARATE field (pseudocode field)
5. Questions must be OUTPUT-BASED and solvable only by dry run.
6. Difficulty must strictly match real TCS / service-based company interviews.

MANDATORY C TOPIC COVERAGE (DISTRIBUTED ACROSS QUESTIONS):
Questions MUST be based on ONE of the following C programming areas.
Across batches, ensure all topics are covered without repetition.

A. Basic Syntax and Data Types
   - int, char, float
   - variable declaration and initialization
   - type casting and expressions

B. Functions and Variables
   - function call flow
   - local vs global variables
   - parameter passing

C. Loops and Control Flow
   - if, if-else
   - nested conditions
   - for, while, do-while loops

D. Data Structures (C-level)
   - arrays (1D and simple 2D)
   - structures
   - basic linked list logic (conceptual)

E. Pointers and Memory Management
   - pointer declaration
   - dereferencing
   - pointer with arrays
   - address/value tracing

F. OOPS-STYLE THINKING IN C
   - structure-based logic
   - function + data flow
   - encapsulation-like behavior (no classes)

G. Input / Output
   - reading values
   - printing output logic
   - formatted output reasoning

H. File Handling (LOGIC ONLY)
   - file open / read / write flow
   - pointer movement concepts

I. Error Handling (LOGIC LEVEL)
   - invalid conditions
   - boundary checks
   - safe execution paths

J. Debugging and Tracing
   - predicting output
   - identifying logical mistakes
   - correcting flow mentally

PSEUDOCODE RULES (VERY STRICT):
7. Pseudocode must be written separately from the question.
8. Pseudocode must be properly indented and readable.
9. Use only simple, C-like logical constructs.
10. Avoid advanced syntax, libraries, or real C keywords.
11. Pseudocode must clearly reflect the C concept being tested.
12. Prefer pointers, loops, arrays, and condition-heavy logic.
13. All pseudocode must reflect service-based interview standards.

OPTION RULES:
14. Exactly 4 options per question.
15. Only ONE option must be correct.
16. Wrong options must be realistic but clearly incorrect.
17. No option should hint the correct answer.

UNIQUENESS RULES (CRITICAL):
18. All ${batchCount} questions must be completely different.
19. No repeated pseudocode structure across questions.
20. No repeated numerical patterns or logic tricks.
21. No reworded or rephrased duplicates.
22. Assume previous batches exist and avoid overlaps.

EXPLANATION RULES (STRICT):
56. First line MUST start with the correct option number and its answer in EXACT format:
- 1) Answer.
57. Second line MUST start with:
- explanation:
and explain step-by-step why the correct option is correct.
58. Third line MUST explain why option 2 is incorrect in 2 to 3 short lines.
59. Fourth line MUST explain why option 3 is incorrect in 2 to 3 short lines.
60. Fifth line MUST explain why option 4 is incorrect in 2 to 3 short lines.
61. All lines MUST start with -.
62. Explanations must be short, simple, and precise.
63. Use clear paragraph sentences only.
64. Do NOT use markdown, numbering, bullets, or symbols other than -.
65. Do NOT add any extra text before or after the explanation.

OUTPUT FORMAT (JSON ONLY â€” NO EXTRA TEXT):
{
  "questions": [
    {
      "question": "Problem statement text",
      "pseudocode": "Properly indented pseudocode related to the question",
      "options": {
        "1": "string",
        "2": "string",
        "3": "string",
        "4": "string"
      },
      "answer": 1,
      "explanation": "strict explanation format only"
    }
  ]
}
`;
}

/* ---------------- TOPIC-WISE PROMPT ---------------- */
export function buildTopicPrompt(topic, batchCount) {
  return `
You are a SERVICE-BASED COMPANY INTERVIEW TOPIC-BASED MCQ GENERATOR.

TARGET COMPANIES:
TCS, Infosys, Wipro, Cognizant, Accenture

TOPIC: "${topic}"

YOUR GOAL:
Generate high-quality interview MCQs strictly from the given TOPIC,
with priority given to concepts that have HIGH INTERVIEW WEIGHTAGE
in service-based company recruitment.

QUESTION RULES (STRICT):
1. Generate EXACTLY ${batchCount} questions.
2. ALL questions must be UNIQUE:
   - Unique within this batch
   - Assume previous batches exist and avoid repetition
3. Every question MUST be strictly from the given TOPIC only.
4. No indirect, related, or mixed concepts.
5. Questions must test understanding, logic, or application
   â€” not memorization.
6. Difficulty must match real service-company interview standards.

INTERVIEW WEIGHTAGE RULES (CRITICAL):
7. Focus on subtopics of "${topic}" that are most frequently asked in:
   - TCS
   - Infosys
   - Wipro
8. Prefer logic-based, output-based, or scenario-based questions.
9. Avoid rare or academic-only subtopics.
10. Prefer patterns seen in real aptitude / technical interview rounds.

OPTION RULES:
11. Exactly 4 options per question.
12. Only ONE option must be correct.
13. Wrong options must be realistic but clearly incorrect.
14. No option should hint the correct answer.

UNIQUENESS RULES:
15. All ${batchCount} questions must be conceptually different.
16. No repeated logic, numbers, or reasoning pattern.
17. No reworded or paraphrased duplicates.
18. Ensure diversity across the topicâ€™s key sub-areas.

EXPLANATION RULES (STRICT):
56. First line MUST start with the correct option number and its answer in EXACT format:
- 1) Answer.
57. Second line MUST start with:
- explanation:
and explain step-by-step why the correct option is correct.
58. Third line MUST explain why option 2 is incorrect in 2 to 3 short lines.
59. Fourth line MUST explain why option 3 is incorrect in 2 to 3 short lines.
60. Fifth line MUST explain why option 4 is incorrect in 2 to 3 short lines.
61. All lines MUST start with -.
62. Explanations must be short, simple, and precise.
63. Use clear paragraph sentences only.
64. Do NOT use markdown, numbering, bullets, or symbols other than -.
65. Do NOT add any extra text before or after the explanation.

OUTPUT FORMAT (JSON ONLY â€” NO EXTRA TEXT):
{
  "questions": [
    {
      "question": "Question text strictly from the given topic",
      "options": {
        "1": "string",
        "2": "string",
        "3": "string",
        "4": "string"
      },
      "answer": 1,
      "explanation": "strict explanation format only"
    }
  ]
}
`;
}

/* ---------- SUBTOPIC LIST PROMPT ---------- */
export function buildSubtopicListPrompt(topic) {
  return `
You are an ENGINEERING INTERVIEW SYLLABUS GENERATOR.

TOPIC: "${topic}"

TASK:
Return ALL important interview subtopics.

RULES:
- Interview focused
- No explanation
- No numbering

OUTPUT JSON ONLY:
{
  "subtopics": ["subtopic1", "subtopic2", "..."]
}
`;
}


/* ---------- MCQ PROMPT (COUNT + STRICT RULES) ---------- */
/**
 * @param {string}  topic             - Main topic
 * @param {object}  subtopicCounts    - { subtopic: count }
 * @param {number}  total             - Sum of all counts
 * @param {object}  prevQuestionsMap  - { subtopic: ["prev q text (truncated)", ...] }
 *                                      Built from history; pass {} on first run.
 */
export function buildMCQPrompt(topic, subtopicCounts, total, prevQuestionsMap = {}) {

  /* Build the PREVIOUSLY ASKED block only when there is history to inject */
  const prevEntries = Object.entries(prevQuestionsMap).filter(([, qs]) => qs.length > 0);
  const prevBlock = prevEntries.length > 0
    ? `
==================== PREVIOUSLY ASKED QUESTIONS â€” ABSOLUTE NON-REPEAT RULE ====================

The questions listed below have ALREADY BEEN GENERATED in earlier batches or previous runs.
You MUST NOT repeat, rephrase, paraphrase, or structurally imitate ANY of them.
Treat this list as a strict blacklist and generate completely different questions.

${prevEntries
  .map(([sub, qs]) =>
    `Subtopic "${sub}" â€” ${qs.length} already asked (DO NOT REUSE):\n` +
    qs.map((q, i) => `  ${i + 1}. ${q}`).join("\n")
  )
  .join("\n\n")}

================================================================================================
`
    : "";

  return `
You are an ENGINEERING INTERVIEW MCQ GENERATOR.

TOPIC: "${topic}"

SUBTOPIC QUESTION COUNTS (MUST BE FOLLOWED EXACTLY):
${JSON.stringify(subtopicCounts, null, 2)}

TOTAL QUESTIONS TO GENERATE: ${total}
${prevBlock}
==================== STRICT GENERATION RULES ====================

QUESTION RULES (MANDATORY):
1. Generate EXACTLY ${total} questions in total.
2. Generate EXACT number of questions PER SUBTOPIC as specified above.
3. ALL questions must be UNIQUE:
   - Unique within this batch
   - Unique compared to ALL previously asked questions listed above
4. Every question MUST be strictly from the given TOPIC only.
5. Do NOT mix concepts from other topics or indirectly related areas.
6. Questions must test understanding, logic, or application â€” NOT memorization.
7. Difficulty must match real-world engineering interview standards
   (service companies + product companies).

DISTRIBUTION RULES (CRITICAL):
8. Questions MUST be generated in an order that respects subtopicCounts.
9. Do NOT exceed or under-generate questions for any subtopic.
10. Do NOT merge multiple subtopics into a single question.

OPTION RULES (STRICT):
11. Exactly 4 options per question.
12. ONLY ONE option must be correct.
13. Wrong options must be realistic but clearly incorrect.
14. No option should hint or reveal the correct answer.

UNIQUENESS RULES (ABSOLUTE):
15. All ${total} questions must be conceptually different.
16. No repeated logic, examples, numbers, or reasoning patterns.
17. No reworded, paraphrased, or structurally similar questions.
18. Ensure diversity across the topic's core and commonly tested areas.

EXPLANATION RULES (VERY STRICT):
19. Explanation MUST follow EXACTLY this 5-line format:
- 1) Correct answer statement.
- explanation: Step-by-step reasoning for why this option is correct.
- Why option 2 is incorrect (2â€“3 short lines).
- Why option 3 is incorrect (2â€“3 short lines).
- Why option 4 is incorrect (2â€“3 short lines).

20. Every line MUST start with a hyphen (-).
21. Use simple, clear, complete sentences.
22. Do NOT use markdown, numbering styles, emojis, or extra symbols.
23. Do NOT add any text before or after the explanation block.

==================== OUTPUT FORMAT (JSON ONLY) ====================

{
  "questions": [
    {
      "question": "Question text here",
      "options": {
        "1": "Option text",
        "2": "Option text",
        "3": "Option text",
        "4": "Option text"
      },
      "answer": 1,
      "explanation": "- 1) Correct answer.\\n- explanation: ...\\n- ...\\n- ...\\n- ..."
    }
  ]
}

NO EXTRA TEXT. NO MARKDOWN. JSON ONLY.
`;
}
