import fs from "fs";

const HISTORY_INJECT_LIMIT = 60;

const INJECT_CHAR_LIMIT = 200;


export function loadHistory(historyPath) {
  if (fs.existsSync(historyPath)) {
    try {
      const raw = fs.readFileSync(historyPath, "utf8");
      const parsed = JSON.parse(raw);
      if (parsed && parsed.version === 1 && parsed.subtopics) {
        console.log(`📂 History loaded from ${historyPath}`);
        return parsed;
      }
    } catch {
      console.warn("⚠️  Could not parse history file — starting fresh.");
    }
  }
  console.log("📂 No existing history — starting fresh.");
  return { version: 1, subtopics: {} };
}

export function saveHistory(history, historyPath) {
  fs.writeFileSync(historyPath, JSON.stringify(history, null, 2), "utf8");
}


export function normalizeText(text) {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}


export function getHistorySet(history, subtopic) {
  const bucket = history.subtopics[subtopic];
  if (!bucket) return new Set();
  return new Set(bucket.questions.map(q => q.normalized));
}


export function isDuplicate(historySet, questionText) {
  return historySet.has(normalizeText(questionText));
}


export function getPreviousTextsForPrompt(history, subtopic) {
  const bucket = history.subtopics[subtopic];
  if (!bucket || !bucket.questions.length) return [];

  return bucket.questions
    .slice(-HISTORY_INJECT_LIMIT)          // most recent N
    .map(q => q.text.slice(0, INJECT_CHAR_LIMIT).trim());
}


export function buildPrevQuestionsMap(history, subtopics) {
  const map = {};
  for (const s of subtopics) {
    const texts = getPreviousTextsForPrompt(history, s);
    if (texts.length) map[s] = texts;
  }
  return map;
}


export function addQuestionsToHistory(history, subtopic, questions) {
  if (!history.subtopics[subtopic]) {
    history.subtopics[subtopic] = { questions: [] };
  }

  const bucket = history.subtopics[subtopic];
  const today = new Date().toISOString().slice(0, 10);

  for (const q of questions) {
    bucket.questions.push({
      text: q.question,
      normalized: normalizeText(q.question),
      date: today
    });
  }
}


export function printHistoryStats(history) {
  console.log("\n📊 History Stats:");
  for (const [sub, bucket] of Object.entries(history.subtopics)) {
    console.log(`   ${sub}: ${bucket.questions.length} recorded question(s)`);
  }
}
