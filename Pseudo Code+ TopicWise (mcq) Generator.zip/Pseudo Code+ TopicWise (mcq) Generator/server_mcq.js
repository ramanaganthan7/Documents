import readline from "readline";
import fs from "fs";
import path from "path";
import { stringify } from "csv-stringify/sync";
import { callVertexModel } from "./services/vertex.js";
import {
  buildSubtopicListPrompt,
  buildMCQPrompt
} from "./services/template.js";
import {
  saveHistory,
  buildPrevQuestionsMap,
  getHistorySet,
  isDuplicate,
  addQuestionsToHistory
} from "./services/history.js";


function emergencyExit(label, err) {
  console.error(`\n\u274c ${label}:`, err?.message ?? err);
  try { rl.close(); } catch { /* already closed */ }
  process.exit(1);
}
process.on("uncaughtException",      err => emergencyExit("Uncaught Exception", err));
process.on("unhandledRejection",     err => emergencyExit("Unhandled Rejection", err));

/* ---------------- CLI ---------------- */

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});
const ask = q => new Promise(r => rl.question(q, r));

/* ---------------- OUTPUT ---------------- */

const OUTPUT_DIR = "./output";
if (!fs.existsSync(OUTPUT_DIR)) fs.mkdirSync(OUTPUT_DIR);

const HISTORY_FILE = path.join(OUTPUT_DIR, "history.json");

const now = new Date();
const pad = n => String(n).padStart(2, "0");
const timestamp =
  `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}_` +
  `${pad(now.getHours())}-${pad(now.getMinutes())}-${pad(now.getSeconds())}`;

const OUTPUT_FILE = path.join(
  OUTPUT_DIR,
  `questions_${timestamp}.csv`
);

/* ---------------- CONFIG ---------------- */

const BATCH_SIZE = 3;   // keep LLM output small to avoid MAX_TOKENS truncation
const MAX_RETRIES = 5;  // more attempts before giving up
const RETRY_DELAY_MS = 2000; // base delay; doubles each attempt (exponential backoff)

/** If the batch loop fails this many cycles in a row (cap already at 1),
 *  abort rather than hang forever. */
const MAX_CONSECUTIVE_FAILURES = 8;

/* ---------------- UTILS ---------------- */

function cleanJSON(text) {
  return text.replace(/```json|```/gi, "").trim();
}

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

/* ---------------- SCHEMA VALIDATION ---------------- */

/* Subtopic schema */
function validateSubtopics(json) {
  if (!json || !Array.isArray(json.subtopics)) return false;

  const seen = new Set();
  for (const s of json.subtopics) {
    if (typeof s !== "string" || !s.trim()) return false;
    if (seen.has(s)) return false;
    seen.add(s);
  }
  return true;
}

/* MCQ schema */
function validateMCQs(json, expectedCount) {
  if (!json || !Array.isArray(json.questions)) return false;
  if (json.questions.length !== expectedCount) return false;

  for (const q of json.questions) {
    if (typeof q.question !== "string" || !q.question.trim()) return false;
    if (typeof q.explanation !== "string" || !q.explanation.trim()) return false;

    if (
      !q.options ||
      typeof q.options !== "object" ||
      !["1", "2", "3", "4"].every(k => typeof q.options[k] === "string")
    ) {
      return false;
    }

    if (
      typeof q.answer !== "number" ||
      q.answer < 1 ||
      q.answer > 4
    ) {
      return false;
    }
  }
  return true;
}

/* ---------------- LLM WITH RETRY ---------------- */

async function callLLMWithRetry(promptBuilder, validator, expected, label) {
  let lastErr;
  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      console.log(`🤖 LLM Call (${label}) | Attempt ${attempt}/${MAX_RETRIES}`);
      const raw = await callVertexModel(promptBuilder());
      const parsed = JSON.parse(cleanJSON(raw));

      if (!validator(parsed, expected)) {
        throw new Error("Schema validation failed");
      }

      console.log(`✅ ${label} schema validated`);
      return parsed;
    } catch (err) {
      lastErr = err;
      console.warn(`⚠️ ${label} failed attempt ${attempt}: ${err.message}`);
      if (attempt < MAX_RETRIES) {
        const delay = RETRY_DELAY_MS * Math.pow(2, attempt - 1); // 2s, 4s, 8s …
        console.log(`⏳ Waiting ${delay / 1000}s before retry…`);
        await sleep(delay);
      }
    }
  }
  throw lastErr;
}

/* ---------------- MAIN ---------------- */

(async function main() {
  try {
  console.log("\n🧠 MCQ Generator (Strict Schema Mode)\n");

  /* Reset history on every run — start completely fresh each time */
  const history = { version: 1, subtopics: {} };
  saveHistory(history, HISTORY_FILE);
  console.log("🗑️  History cleared — starting fresh this run.\n");

  const topic = await ask("📘 Enter main topic: ");

  console.log("\n🔍 Fetching subtopics...");
  const subtopicResp = await callLLMWithRetry(
    () => buildSubtopicListPrompt(topic),
    validateSubtopics,
    null,
    "Subtopic Fetch"
  );

  const subtopics = subtopicResp.subtopics;

  console.log("\n📚 Subtopics Found:");
  subtopics.forEach((s, i) => console.log(`${i + 1}. ${s}`));

  const perSubtopicCountRaw = await ask("\n\uD83D\uDD22 Enter number of questions per subtopic: ");
  const perSubtopicCount = Number(perSubtopicCountRaw);
  if (!Number.isInteger(perSubtopicCount) || perSubtopicCount < 1) {
    console.error("\u274c Invalid input: please enter a positive whole number.");
    rl.close();
    process.exit(1);
  }

  /* CSV INIT */
  fs.writeFileSync(
    OUTPUT_FILE,
    stringify([], {
      header: true,
      columns: [
        "S.No",
        "Topic",
        "Subtopic",
        "Question",
        "Options(JSON)",
        "Answer",
        "Explanation"
      ]
    })
  );

  let sNo = 1;

  const remainingMap = {};
  subtopics.forEach(s => remainingMap[s] = perSubtopicCount);

  // Effective cap starts at BATCH_SIZE; halves whenever a batch keeps failing
  let dynamicBatchCap = BATCH_SIZE;
  let consecutiveFailures = 0;  // circuit breaker counter

  /* ---------------- BATCH LOOP ---------------- */

  while (Object.values(remainingMap).some(v => v > 0)) {
    console.log("\n🔁 Starting new batch cycle");

    let batch = {};
    let batchTotal = 0;

    console.log("📊 Remaining:", remainingMap);
    console.log(`📐 Dynamic batch cap: ${dynamicBatchCap}`);

    for (const s of subtopics) {
      if (remainingMap[s] > 0 && batchTotal < dynamicBatchCap) {
        const canTake = Math.min(
          remainingMap[s],
          dynamicBatchCap - batchTotal
        );

        console.log(`➕ Adding ${canTake} → ${s}`);

        batch[s] = canTake;
        remainingMap[s] -= canTake;
        batchTotal += canTake;

        console.log(`📦 Batch size: ${batchTotal}/${dynamicBatchCap}`);
      }
    }

    console.log("🧩 Finalized batch:", batch);

    const total = Object.values(batch).reduce((a, b) => a + b, 0);

    /* Build history context for the subtopics in this batch */
    const prevQuestionsMap = buildPrevQuestionsMap(history, Object.keys(batch));
    const prevCount = Object.values(prevQuestionsMap).reduce((a, b) => a + b.length, 0);
    if (prevCount > 0) {
      console.log(`🗂️  Injecting ${prevCount} previously asked question(s) into prompt to prevent repeats`);
    }

    let mcqResp;
    try {
      mcqResp = await callLLMWithRetry(
        () => buildMCQPrompt(topic, batch, total, prevQuestionsMap),
        validateMCQs,
        total,
        "MCQ Generation"
      );
    } catch (batchErr) {
      console.error(`\u274c Batch failed after all retries: ${batchErr.message}`);
      console.log("\u267b\ufe0f  Restoring batch questions back to queue and shrinking batch cap\u2026");

      // Put questions back so they are not lost
      for (const [s, count] of Object.entries(batch)) {
        remainingMap[s] = (remainingMap[s] || 0) + count;
      }

      // Halve the cap (minimum 1) so the next attempt uses a smaller batch
      dynamicBatchCap = Math.max(1, Math.floor(dynamicBatchCap / 2));
      console.log(`\uD83D\uDCC9 New batch cap: ${dynamicBatchCap}`);

      // Circuit breaker — prevent infinite hang when API is permanently broken
      consecutiveFailures++;
      console.log(`\uD83D\uDEA8 Consecutive failure count: ${consecutiveFailures}/${MAX_CONSECUTIVE_FAILURES}`);
      if (consecutiveFailures >= MAX_CONSECUTIVE_FAILURES) {
        const stillPending = Object.values(remainingMap).reduce((a, b) => a + b, 0);
        console.error(`\u274c Aborting after ${MAX_CONSECUTIVE_FAILURES} consecutive failed batches.`);
        console.error(`   ${stillPending} question(s) could not be generated.`);
        console.log(`\uD83D\uDCC4 Partial results saved to: ${OUTPUT_FILE}`);
        break;
      }

      // Brief pause before the next cycle
      await sleep(3000);
      continue;
    }

    // Successful batch — gradually recover cap toward BATCH_SIZE
    consecutiveFailures = 0;  // reset circuit breaker on success
    if (dynamicBatchCap < BATCH_SIZE) {
      dynamicBatchCap = Math.min(BATCH_SIZE, dynamicBatchCap + 1);
      console.log(`📈 Batch cap restored to: ${dynamicBatchCap}`);
    }

    console.log("📥 Writing to CSV (with dedup check)...");

    let idx = 0;
    let batchDuplicates = 0;

    for (const [subtopic, count] of Object.entries(batch)) {
      /* Build a per-subtopic Set for O(1) lookup against full history */
      const histSet = getHistorySet(history, subtopic);
      const newlyAccepted = [];

      for (let i = 0; i < count; i++) {
        const q = mcqResp.questions[idx++];

        if (isDuplicate(histSet, q.question)) {
          console.warn(`⚠️  Duplicate detected in "${subtopic}" — skipping & re-queuing: ${q.question.slice(0, 80)}…`);
          remainingMap[subtopic] = (remainingMap[subtopic] || 0) + 1;
          batchDuplicates++;
          continue;
        }

        /* Accept: write to CSV, add to in-memory history Set so same-batch
           duplicates are caught even before the next saveHistory */
        histSet.add(q.question.toLowerCase().replace(/[^a-z0-9\s]/g, "").replace(/\s+/g, " ").trim());
        newlyAccepted.push(q);

        fs.appendFileSync(
            OUTPUT_FILE,
            stringify([[
              sNo++,
              topic,
              subtopic,
              q.question,
              JSON.stringify(q.options),
              q.answer,
              q.explanation
            ]])
          );
      }

      /* Persist accepted questions to history */
      if (newlyAccepted.length > 0) {
        addQuestionsToHistory(history, subtopic, newlyAccepted);
      }
    }

    /* Save history after every successful batch */
    try {
      saveHistory(history, HISTORY_FILE);
    } catch (saveErr) {
      console.warn(`\u26a0\ufe0f  Could not save history: ${saveErr.message} (continuing)`);
    }

    if (batchDuplicates > 0) {
      console.log(`♻️  ${batchDuplicates} duplicate(s) re-queued; will be generated in the next cycle`);
    }
    console.log("✅ Batch saved");
  }

  console.log(`\n\uD83C\uDF89 DONE\n\uD83D\uDCC4 File: ${OUTPUT_FILE}`);

  } catch (fatalErr) {
    console.error("\n\u274c Fatal error:", fatalErr.message);
  } finally {
    try { rl.close(); } catch { /* already closed */ }
  }
})();
